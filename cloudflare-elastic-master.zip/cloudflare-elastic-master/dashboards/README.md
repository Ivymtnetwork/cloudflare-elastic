
##### Kibana Dashboards

Pre-built dashboards for viewing Cloudflare logs and metrics. You must import these into Kibana using the **Import Saved Objects** interface (Management/Kibana/Saved Objects).


![Import Dashboards](./import-kibana-dashboards.png?raw=true "Title")
